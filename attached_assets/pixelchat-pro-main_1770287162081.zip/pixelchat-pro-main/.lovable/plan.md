

# WhatsApp Web Clone for PixelCRM

## Overview
A pixel-perfect WhatsApp Web-style messaging interface for team collaboration, with role-based access control (Admin, Support, Designer) and custom business features like chat assignments, tags, and quick replies.

---

## Phase 1: Authentication & User Management

### Login & Signup System
- Email/password authentication with Supabase Auth
- Clean, professional login page
- Password recovery flow

### Role-Based User System
- Three roles: **Admin**, **Support**, **Designer**
- User profiles with name, avatar, and role
- Secure role storage in separate table (not in profiles) to prevent privilege escalation

---

## Phase 2: WhatsApp Web UI Clone (Dark Theme)

### Main Layout Structure
- **Full-screen three-panel layout** matching WhatsApp Web exactly
- Left panel: Chat list with search
- Center panel: Active conversation with message history
- Right panel: Contact info & actions (collapsible)

### Left Sidebar - Chat List
- **Header**: "WhatsApp" title with user avatar and menu
- **Search bar**: Filter chats by name/number
- **Filter tabs** (role-dependent):
  - Admin/Support: All Chats | New Chats | By Designer
  - Designer: My Chats | New Chats

### Chat List Items (matching WhatsApp exactly)
- Contact avatar (circle)
- Client name or phone number
- Last message preview (truncated)
- Timestamp (relative: "Yesterday", "14:51")
- Unread message count badge
- Color-coded chat tag indicator
- Assigned designer name (Admin/Support only)

### Center Panel - Conversation View
- **Header**: Contact name, avatar, status indicators
- **Message bubbles**:
  - Incoming messages (left, grey background)
  - Outgoing messages (right, green background)
  - Timestamps on each message
  - Delivery/read indicators (double checkmarks)
- **Voice note player** for received audio
- **File attachments** with download option
- **Date separators** ("Today", "Yesterday")

### Message Input Area
- Text input field ("Type a message")
- Emoji picker button
- File attachment button (multi-file support)
- **No microphone button** (as specified)
- "/" trigger for quick replies dropdown

### Right Panel - Contact Info
- Large contact avatar
- Contact name and phone number
- Chat tag selector (dropdown with color options)
- Assigned designer display/selector
- Media & files shared
- Action buttons (based on role permissions)

---

## Phase 3: Chat Tag System

### Available Tags (Color-Coded)
- 🟡 **New** - Unassigned incoming chats
- 🔵 **Working** - Actively being handled
- 🟠 **Pending** - Awaiting client response
- 🔴 **Issues** - Problems or escalations
- 🟢 **Satisfied Client** - Complete (auto-unassigns)

### Tag Behavior
- Visual indicator on each chat in the list
- Dropdown selector in chat panel
- Role-based editing permissions enforced
- Auto-unassign when Designer marks "Satisfied Client"

---

## Phase 4: Quick Reply System

### Shortcut Functionality
- Type "/" in message input to trigger dropdown
- Shows all available message templates
- Click or arrow-key select to insert

### Example Shortcuts
- `/payment` → Payment instructions message
- `/ready` → "Your design is ready!" message
- `/thanks` → Thank you message

### Admin Management Interface
- Create, edit, delete shortcuts
- Shortcut name and full message template
- Support & Designers can use but not modify

---

## Phase 5: Role-Based Access Control

### Admin Capabilities
- View all chats across the system
- Read and send messages in any chat
- Assign/reassign chats to designers
- Change tags on any chat
- Manage quick reply templates
- Access all system settings

### Support Capabilities
- View all chats
- Read and send messages
- Assign chats to designers
- Change tags
- Cannot delete chats or access system settings

### Designer Capabilities
- See only chats assigned to them
- Reply and send files in assigned chats
- Change tags on assigned chats only
- Cannot see unassigned chats
- Cannot see other designers' chats

---

## Phase 6: Backend Integration (Supabase)

### Database Schema
- **profiles**: User info and role references
- **user_roles**: Role assignments (secure, separate table)
- **chats**: Client conversations with assignment data
- **messages**: Individual messages with metadata
- **chat_tags**: Tag definitions and colors
- **message_templates**: Quick reply shortcuts
- **activity_logs**: Audit trail for all actions

### Real-Time Features
- Live message updates using Supabase Realtime
- Instant chat assignment notifications
- Online presence indicators

### Security
- Row-Level Security (RLS) enforcing role permissions
- Backend validation (not UI-only restrictions)
- Audit logging for compliance

---

## Phase 7: WhatsApp Cloud API Integration

### Webhook Handling
- Edge function to receive incoming messages
- Parse and store messages in database
- Trigger real-time updates

### Outgoing Messages
- Send text messages via API
- Upload and send files
- Receive delivery/read receipts

### Media Handling
- Download and store incoming media
- Supabase Storage for file management
- Voice note playback support

---

## Mock Data for Testing

Before API integration, the UI will include:
- 10+ sample conversations with realistic messages
- Mix of text, voice notes, and file attachments
- Various chat tags and assignment states
- Multiple "users" to demonstrate role views

---

## Technical Stack

- **Frontend**: React + TypeScript + Tailwind CSS
- **UI Components**: shadcn/ui (customized for WhatsApp theme)
- **Authentication**: Supabase Auth
- **Database**: Supabase PostgreSQL
- **Real-time**: Supabase Realtime subscriptions
- **File Storage**: Supabase Storage
- **API Integration**: Supabase Edge Functions

