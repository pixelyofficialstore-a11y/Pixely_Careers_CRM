import { WhatsAppLayout } from '@/components/whatsapp/WhatsAppLayout';

const Index = () => {
  return <WhatsAppLayout />;
};

export default Index;
