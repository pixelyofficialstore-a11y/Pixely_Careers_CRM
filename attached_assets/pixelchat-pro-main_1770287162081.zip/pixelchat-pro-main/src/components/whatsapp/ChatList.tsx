 import { useState } from 'react';
 import { Input } from '@/components/ui/input';
 import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
 import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
 import { ChatListItem } from './ChatListItem';
 import { Chat, User, UserRole } from '@/types/whatsapp';
 import { mockChats, mockUsers, currentUser } from '@/data/mockData';
 import { Search, MoreVertical, ChevronDown } from 'lucide-react';
 import { cn } from '@/lib/utils';
 
 interface ChatListProps {
   activeChat: Chat | null;
   onSelectChat: (chat: Chat) => void;
   userRole: UserRole;
 }
 
 export function ChatList({ activeChat, onSelectChat, userRole }: ChatListProps) {
   const [searchQuery, setSearchQuery] = useState('');
   const [activeTab, setActiveTab] = useState('all');
   const [expandedDesigners, setExpandedDesigners] = useState<string[]>([]);
 
   // Get designers for "By Designer" tab
   const designers = mockUsers.filter(u => u.role === 'designer');
 
   // Filter chats based on search and role
   const getFilteredChats = () => {
     let filtered = [...mockChats];
 
     // Apply search filter
     if (searchQuery) {
       const query = searchQuery.toLowerCase();
       filtered = filtered.filter(chat => 
         chat.contact.name?.toLowerCase().includes(query) ||
         chat.contact.phone.toLowerCase().includes(query)
       );
     }
 
     // Apply role-based filtering
     if (userRole === 'designer') {
       // Designers only see their assigned chats
       filtered = filtered.filter(chat => 
         chat.assignedTo?.id === currentUser.id || chat.tag === 'new'
       );
     }
 
     // Apply tab filter
     switch (activeTab) {
       case 'new':
         filtered = filtered.filter(chat => chat.tag === 'new');
         break;
       case 'my':
         filtered = filtered.filter(chat => chat.assignedTo?.id === currentUser.id);
         break;
       case 'designer':
         // This is handled separately in the UI
         break;
     }
 
     // Sort by last message timestamp
     return filtered.sort((a, b) => {
       const aTime = a.lastMessage?.timestamp.getTime() || 0;
       const bTime = b.lastMessage?.timestamp.getTime() || 0;
       return bTime - aTime;
     });
   };
 
   const getChatsByDesigner = (designerId: string) => {
     return mockChats
       .filter(chat => chat.assignedTo?.id === designerId)
       .sort((a, b) => {
         const aTime = a.lastMessage?.timestamp.getTime() || 0;
         const bTime = b.lastMessage?.timestamp.getTime() || 0;
         return bTime - aTime;
       });
   };
 
   const toggleDesigner = (designerId: string) => {
     setExpandedDesigners(prev => 
       prev.includes(designerId) 
         ? prev.filter(id => id !== designerId)
         : [...prev, designerId]
     );
   };
 
   const filteredChats = getFilteredChats();
   const isAdminOrSupport = userRole === 'admin' || userRole === 'support';
 
   return (
     <div className="flex flex-col h-full bg-whatsapp-bg-panel border-r border-whatsapp-divider">
       {/* Header */}
       <div className="flex items-center justify-between px-4 py-3 bg-whatsapp-header">
         <Avatar className="h-10 w-10 cursor-pointer">
           <AvatarImage src={currentUser.avatar} />
           <AvatarFallback className="bg-whatsapp-bg-input text-whatsapp-text-primary">
             {currentUser.name.charAt(0)}
           </AvatarFallback>
         </Avatar>
         <div className="flex items-center gap-4">
           <button className="text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors">
             <MoreVertical className="h-5 w-5" />
           </button>
         </div>
       </div>
 
       {/* Search */}
       <div className="px-3 py-2">
         <div className="relative">
           <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-whatsapp-icon" />
           <Input
             value={searchQuery}
             onChange={(e) => setSearchQuery(e.target.value)}
             placeholder="Search or start new chat"
             className="pl-10 bg-whatsapp-bg-input border-0 text-whatsapp-text-primary placeholder:text-whatsapp-text-secondary rounded-lg h-9"
           />
         </div>
       </div>
 
       {/* Filter Tabs */}
       <div className="px-2 py-1">
         <Tabs value={activeTab} onValueChange={setActiveTab}>
           <TabsList className="w-full bg-transparent gap-1 h-auto p-0">
             {isAdminOrSupport ? (
               <>
                 <TabsTrigger 
                   value="all"
                   className="flex-1 px-3 py-1.5 text-xs rounded-full data-[state=active]:bg-whatsapp-green data-[state=active]:text-white bg-whatsapp-bg-input text-whatsapp-text-secondary"
                 >
                   All
                 </TabsTrigger>
                 <TabsTrigger 
                   value="new"
                   className="flex-1 px-3 py-1.5 text-xs rounded-full data-[state=active]:bg-whatsapp-green data-[state=active]:text-white bg-whatsapp-bg-input text-whatsapp-text-secondary"
                 >
                   New
                 </TabsTrigger>
                 <TabsTrigger 
                   value="designer"
                   className="flex-1 px-3 py-1.5 text-xs rounded-full data-[state=active]:bg-whatsapp-green data-[state=active]:text-white bg-whatsapp-bg-input text-whatsapp-text-secondary"
                 >
                   By Designer
                 </TabsTrigger>
               </>
             ) : (
               <>
                 <TabsTrigger 
                   value="my"
                   className="flex-1 px-3 py-1.5 text-xs rounded-full data-[state=active]:bg-whatsapp-green data-[state=active]:text-white bg-whatsapp-bg-input text-whatsapp-text-secondary"
                 >
                   My Chats
                 </TabsTrigger>
                 <TabsTrigger 
                   value="new"
                   className="flex-1 px-3 py-1.5 text-xs rounded-full data-[state=active]:bg-whatsapp-green data-[state=active]:text-white bg-whatsapp-bg-input text-whatsapp-text-secondary"
                 >
                   New
                 </TabsTrigger>
               </>
             )}
           </TabsList>
         </Tabs>
       </div>
 
       {/* Chat List */}
       <ScrollArea className="flex-1">
         {activeTab === 'designer' && isAdminOrSupport ? (
           // Designer grouped view
           <div className="py-1">
             {designers.map(designer => {
               const designerChats = getChatsByDesigner(designer.id);
               const isExpanded = expandedDesigners.includes(designer.id);
               
               return (
                 <Collapsible 
                   key={designer.id} 
                   open={isExpanded}
                   onOpenChange={() => toggleDesigner(designer.id)}
                 >
                   <CollapsibleTrigger className="w-full">
                     <div className="flex items-center gap-3 px-4 py-3 hover:bg-whatsapp-hover transition-colors">
                       <Avatar className="h-10 w-10">
                         <AvatarImage src={designer.avatar} />
                         <AvatarFallback className="bg-whatsapp-green text-white">
                           {designer.name.charAt(0)}
                         </AvatarFallback>
                       </Avatar>
                       <div className="flex-1 text-left">
                         <div className="text-whatsapp-text-primary font-medium">
                           {designer.name}
                         </div>
                         <div className="text-xs text-whatsapp-text-secondary">
                           {designerChats.length} chats
                         </div>
                       </div>
                       <ChevronDown className={cn(
                         'h-4 w-4 text-whatsapp-icon transition-transform',
                         isExpanded && 'rotate-180'
                       )} />
                     </div>
                   </CollapsibleTrigger>
                   <CollapsibleContent>
                     <div className="pl-4">
                       {designerChats.map(chat => (
                         <ChatListItem
                           key={chat.id}
                           chat={chat}
                           isActive={activeChat?.id === chat.id}
                           onClick={() => onSelectChat(chat)}
                           showAssignee={false}
                         />
                       ))}
                     </div>
                   </CollapsibleContent>
                 </Collapsible>
               );
             })}
           </div>
         ) : (
           // Regular list view
           <div>
             {filteredChats.length === 0 ? (
               <div className="text-center py-8 text-whatsapp-text-secondary">
                 No chats found
               </div>
             ) : (
               filteredChats.map(chat => (
                 <ChatListItem
                   key={chat.id}
                   chat={chat}
                   isActive={activeChat?.id === chat.id}
                   onClick={() => onSelectChat(chat)}
                   showAssignee={isAdminOrSupport}
                 />
               ))
             )}
           </div>
         )}
       </ScrollArea>
     </div>
   );
 }