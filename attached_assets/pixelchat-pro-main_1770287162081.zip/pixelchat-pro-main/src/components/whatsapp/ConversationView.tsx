 import { useRef, useEffect } from 'react';
 import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { MessageBubble } from './MessageBubble';
 import { MessageInput } from './MessageInput';
 import { Chat, Message } from '@/types/whatsapp';
 import { MoreVertical, Search, Phone, Video } from 'lucide-react';
 import { format, isToday, isYesterday, isSameDay } from 'date-fns';
 
 interface ConversationViewProps {
   chat: Chat | null;
   onSendMessage: (chatId: string, content: string) => void;
   onToggleContactInfo: () => void;
 }
 
 export function ConversationView({ chat, onSendMessage, onToggleContactInfo }: ConversationViewProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
 
   useEffect(() => {
     // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
   }, [chat?.messages]);
 
   if (!chat) {
     return (
       <div className="flex-1 flex items-center justify-center bg-whatsapp-bg-chat">
         <div className="text-center">
           <div className="w-64 h-64 mx-auto mb-4 opacity-20">
             <svg viewBox="0 0 303 172" className="fill-whatsapp-text-secondary">
               <path d="M229.565 160.229C262.212 149.245 286.931 118.241 283.39 73.4194C278.009 5.31929 212.315 -11.5738 171.472 8.48673C115.998 37.0981 60.0166 25.0687 28.9267 69.5983C-2.16336 114.128 24.9692 162.53 68.849 168.993C112.729 175.456 186.392 175.074 229.565 160.229Z" />
               <path fill="#FFFFFF" d="M135.5 80.5C135.5 87.4036 129.904 93 123 93C116.096 93 110.5 87.4036 110.5 80.5C110.5 73.5964 116.096 68 123 68C129.904 68 135.5 73.5964 135.5 80.5Z" />
               <path fill="#FFFFFF" d="M192.5 80.5C192.5 87.4036 186.904 93 180 93C173.096 93 167.5 87.4036 167.5 80.5C167.5 73.5964 173.096 68 180 68C186.904 68 192.5 73.5964 192.5 80.5Z" />
             </svg>
           </div>
           <h2 className="text-2xl font-light text-whatsapp-text-primary mb-2">
             WhatsApp Web
           </h2>
           <p className="text-sm text-whatsapp-text-secondary max-w-md">
             Send and receive messages without keeping your phone online.
             <br />
             Select a chat to start messaging.
           </p>
         </div>
       </div>
     );
   }
 
   const { contact, messages } = chat;
 
   const getDateLabel = (date: Date) => {
     if (isToday(date)) return 'Today';
     if (isYesterday(date)) return 'Yesterday';
     return format(date, 'dd/MM/yyyy');
   };
 
   const getOnlineStatus = () => {
     if (contact.isOnline) return 'online';
     if (contact.lastSeen) {
       return `last seen ${format(contact.lastSeen, 'HH:mm')}`;
     }
     return '';
   };
 
   // Group messages by date
   const groupedMessages: { date: Date; messages: Message[] }[] = [];
   messages.forEach(message => {
     const lastGroup = groupedMessages[groupedMessages.length - 1];
     if (lastGroup && isSameDay(lastGroup.date, message.timestamp)) {
       lastGroup.messages.push(message);
     } else {
       groupedMessages.push({
         date: message.timestamp,
         messages: [message],
       });
     }
   });
 
   const handleSendMessage = (content: string) => {
     onSendMessage(chat.id, content);
   };
 
   return (
     <div className="flex-1 flex flex-col bg-whatsapp-bg-chat min-w-0">
       {/* Header */}
       <div 
         onClick={onToggleContactInfo}
         className="flex items-center justify-between px-4 py-2.5 bg-whatsapp-header cursor-pointer"
       >
         <div className="flex items-center gap-3">
           <Avatar className="h-10 w-10">
             <AvatarImage src={contact.avatar} />
             <AvatarFallback className="bg-whatsapp-bg-input text-whatsapp-text-primary">
               {(contact.name || contact.phone).charAt(0).toUpperCase()}
             </AvatarFallback>
           </Avatar>
           <div>
             <h3 className="font-medium text-whatsapp-text-primary">
               {contact.name || contact.phone}
             </h3>
             <p className="text-xs text-whatsapp-text-secondary">
               {getOnlineStatus()}
             </p>
           </div>
         </div>
         <div className="flex items-center gap-4">
           <button className="text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors">
             <Search className="h-5 w-5" />
           </button>
           <button className="text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors">
             <MoreVertical className="h-5 w-5" />
           </button>
         </div>
       </div>
 
       {/* Messages */}
      <ScrollArea className="flex-1 px-16 py-4">
         <div className="space-y-4">
           {groupedMessages.map((group, groupIndex) => (
             <div key={groupIndex}>
               {/* Date separator */}
               <div className="flex justify-center mb-4">
                 <span className="px-3 py-1 bg-whatsapp-bubble-in text-whatsapp-text-secondary text-xs rounded-lg">
                   {getDateLabel(group.date)}
                 </span>
               </div>
               
               {/* Messages for this date */}
               <div className="space-y-1">
                 {group.messages.map(message => (
                   <MessageBubble key={message.id} message={message} />
                 ))}
               </div>
             </div>
           ))}
          <div ref={messagesEndRef} />
         </div>
       </ScrollArea>
 
       {/* Input */}
       <MessageInput 
         onSendMessage={handleSendMessage}
         onAttachFile={() => console.log('Attach file')}
       />
     </div>
   );
 }