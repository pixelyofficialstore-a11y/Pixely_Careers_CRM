 import { Message } from '@/types/whatsapp';
 import { cn } from '@/lib/utils';
 import { Check, CheckCheck, FileIcon, Download, Play, Pause } from 'lucide-react';
 import { format } from 'date-fns';
 import { useState } from 'react';
 
 interface MessageBubbleProps {
   message: Message;
 }
 
 export function MessageBubble({ message }: MessageBubbleProps) {
   const [isPlaying, setIsPlaying] = useState(false);
   const isOutgoing = message.sender === 'user';
 
   const formatTime = (date: Date) => format(date, 'HH:mm');
 
   const getStatusIcon = () => {
     if (!isOutgoing) return null;
     
     if (message.status === 'read') {
       return <CheckCheck className="h-4 w-4 text-whatsapp-teal" />;
     }
     if (message.status === 'delivered') {
       return <CheckCheck className="h-4 w-4 text-whatsapp-icon" />;
     }
     return <Check className="h-4 w-4 text-whatsapp-icon" />;
   };
 
   const formatFileSize = (bytes?: number) => {
     if (!bytes) return '';
     if (bytes < 1024) return `${bytes} B`;
     if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
     return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
   };
 
   const formatDuration = (seconds?: number) => {
     if (!seconds) return '0:00';
     const mins = Math.floor(seconds / 60);
     const secs = seconds % 60;
     return `${mins}:${secs.toString().padStart(2, '0')}`;
   };
 
   const renderContent = () => {
     switch (message.type) {
       case 'image':
         return (
           <div className="max-w-[280px]">
             <img
               src={message.fileUrl}
               alt="Shared image"
               className="rounded-lg max-w-full h-auto"
             />
             <div className="flex items-center justify-end gap-1 mt-1">
               <span className="text-xs text-whatsapp-text-secondary">
                 {formatTime(message.timestamp)}
               </span>
               {getStatusIcon()}
             </div>
           </div>
         );
 
       case 'file':
         return (
           <div className="flex items-center gap-3 min-w-[200px]">
             <div className="h-12 w-12 rounded-lg bg-whatsapp-bg-dark flex items-center justify-center flex-shrink-0">
               <FileIcon className="h-6 w-6 text-whatsapp-text-secondary" />
             </div>
             <div className="flex-1 min-w-0">
               <div className="text-sm text-whatsapp-text-primary truncate">
                 {message.fileName || 'Document'}
               </div>
               <div className="text-xs text-whatsapp-text-secondary">
                 {formatFileSize(message.fileSize)}
               </div>
             </div>
             <button className="p-2 hover:bg-whatsapp-hover rounded-full transition-colors">
               <Download className="h-5 w-5 text-whatsapp-icon" />
             </button>
             <div className="flex items-center gap-1">
               <span className="text-xs text-whatsapp-text-secondary">
                 {formatTime(message.timestamp)}
               </span>
               {getStatusIcon()}
             </div>
           </div>
         );
 
       case 'voice':
         return (
           <div className="flex items-center gap-3 min-w-[240px]">
             <button 
               onClick={() => setIsPlaying(!isPlaying)}
               className="h-10 w-10 rounded-full bg-whatsapp-green flex items-center justify-center flex-shrink-0"
             >
               {isPlaying ? (
                 <Pause className="h-5 w-5 text-white" />
               ) : (
                 <Play className="h-5 w-5 text-white ml-0.5" />
               )}
             </button>
             <div className="flex-1">
               {/* Waveform visualization */}
               <div className="flex items-center gap-0.5 h-6">
                 {Array.from({ length: 30 }).map((_, i) => (
                   <div
                     key={i}
                     className="w-1 bg-whatsapp-text-secondary rounded-full"
                     style={{ height: `${Math.random() * 16 + 4}px` }}
                   />
                 ))}
               </div>
               <div className="flex items-center justify-between mt-1">
                 <span className="text-xs text-whatsapp-text-secondary">
                   {formatDuration(message.duration)}
                 </span>
               </div>
             </div>
             <div className="flex items-center gap-1">
               <span className="text-xs text-whatsapp-text-secondary">
                 {formatTime(message.timestamp)}
               </span>
               {getStatusIcon()}
             </div>
           </div>
         );
 
       default:
         return (
           <>
             <p className="text-sm whitespace-pre-wrap break-words">
               {message.content}
             </p>
             <div className="flex items-center justify-end gap-1 mt-1">
               <span className="text-xs text-whatsapp-text-secondary">
                 {formatTime(message.timestamp)}
               </span>
               {getStatusIcon()}
             </div>
           </>
         );
     }
   };
 
   return (
     <div className={cn('flex', isOutgoing ? 'justify-end' : 'justify-start')}>
       <div
         className={cn(
           'max-w-[65%] px-3 py-2 rounded-lg',
           isOutgoing
             ? 'bg-whatsapp-bubble-out text-white rounded-tr-none'
             : 'bg-whatsapp-bubble-in text-whatsapp-text-primary rounded-tl-none'
         )}
       >
         {renderContent()}
       </div>
     </div>
   );
 }