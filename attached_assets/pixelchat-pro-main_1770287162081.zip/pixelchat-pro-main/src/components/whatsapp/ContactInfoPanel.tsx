 import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
 import { ScrollArea } from '@/components/ui/scroll-area';
 import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
 import { Chat, ChatTag, TAG_CONFIG, UserRole } from '@/types/whatsapp';
 import { mockUsers } from '@/data/mockData';
 import { X, Star, Bell, Lock, FileIcon, Image as ImageIcon, Link } from 'lucide-react';
 import { cn } from '@/lib/utils';
 
 interface ContactInfoPanelProps {
   chat: Chat;
   userRole: UserRole;
   onClose: () => void;
   onUpdateTag: (chatId: string, tag: ChatTag) => void;
   onAssignDesigner: (chatId: string, designerId: string | null) => void;
 }
 
 export function ContactInfoPanel({ 
   chat, 
   userRole, 
   onClose,
   onUpdateTag,
   onAssignDesigner 
 }: ContactInfoPanelProps) {
   const { contact, tag, assignedTo, messages } = chat;
   const designers = mockUsers.filter(u => u.role === 'designer');
   const canEditTag = userRole === 'admin' || userRole === 'support' || 
     (userRole === 'designer' && assignedTo?.id === mockUsers.find(u => u.role === 'designer')?.id);
   const canAssign = userRole === 'admin' || userRole === 'support';
 
   // Get shared media
   const sharedImages = messages.filter(m => m.type === 'image');
   const sharedFiles = messages.filter(m => m.type === 'file');
 
   return (
     <div className="w-[340px] flex flex-col bg-whatsapp-bg-panel border-l border-whatsapp-divider">
       {/* Header */}
       <div className="flex items-center gap-4 px-4 py-4 bg-whatsapp-header">
         <button
           onClick={onClose}
           className="text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors"
         >
           <X className="h-6 w-6" />
         </button>
         <span className="text-whatsapp-text-primary font-medium">Contact info</span>
       </div>
 
       <ScrollArea className="flex-1">
         {/* Contact Avatar & Name */}
         <div className="flex flex-col items-center py-8 bg-whatsapp-header">
           <Avatar className="h-48 w-48 mb-4">
             <AvatarImage src={contact.avatar} />
             <AvatarFallback className="bg-whatsapp-bg-input text-whatsapp-text-primary text-6xl">
               {(contact.name || contact.phone).charAt(0).toUpperCase()}
             </AvatarFallback>
           </Avatar>
           <h2 className="text-xl font-medium text-whatsapp-text-primary">
             {contact.name || contact.phone}
           </h2>
           <p className="text-sm text-whatsapp-text-secondary mt-1">
             {contact.phone}
           </p>
         </div>
 
         {/* Divider */}
         <div className="h-2 bg-whatsapp-bg-dark" />
 
         {/* Chat Tag */}
         <div className="px-6 py-4 bg-whatsapp-header">
           <label className="text-sm text-whatsapp-text-secondary mb-2 block">
             Chat Tag
           </label>
           <Select
             value={tag}
             onValueChange={(value) => onUpdateTag(chat.id, value as ChatTag)}
             disabled={!canEditTag}
           >
             <SelectTrigger className="bg-whatsapp-bg-input border-0 text-whatsapp-text-primary">
               <SelectValue>
                 <div className="flex items-center gap-2">
                   <div className={cn('h-3 w-3 rounded-full', TAG_CONFIG[tag].bgClass)} />
                   <span>{TAG_CONFIG[tag].label}</span>
                 </div>
               </SelectValue>
             </SelectTrigger>
             <SelectContent className="bg-whatsapp-bg-panel border-whatsapp-divider">
               {Object.entries(TAG_CONFIG).map(([key, config]) => (
                 <SelectItem 
                   key={key} 
                   value={key}
                   className="text-whatsapp-text-primary focus:bg-whatsapp-hover focus:text-whatsapp-text-primary"
                 >
                   <div className="flex items-center gap-2">
                     <div className={cn('h-3 w-3 rounded-full', config.bgClass)} />
                     <span>{config.label}</span>
                   </div>
                 </SelectItem>
               ))}
             </SelectContent>
           </Select>
         </div>
 
         {/* Assigned Designer (Admin/Support only) */}
         {canAssign && (
           <>
             <div className="h-px bg-whatsapp-divider" />
             <div className="px-6 py-4 bg-whatsapp-header">
               <label className="text-sm text-whatsapp-text-secondary mb-2 block">
                 Assigned Designer
               </label>
               <Select
                 value={assignedTo?.id || 'unassigned'}
                 onValueChange={(value) => onAssignDesigner(chat.id, value === 'unassigned' ? null : value)}
               >
                 <SelectTrigger className="bg-whatsapp-bg-input border-0 text-whatsapp-text-primary">
                   <SelectValue>
                     {assignedTo ? (
                       <div className="flex items-center gap-2">
                         <Avatar className="h-6 w-6">
                           <AvatarImage src={assignedTo.avatar} />
                           <AvatarFallback className="bg-whatsapp-green text-white text-xs">
                             {assignedTo.name.charAt(0)}
                           </AvatarFallback>
                         </Avatar>
                         <span>{assignedTo.name}</span>
                       </div>
                     ) : (
                       <span className="text-whatsapp-text-secondary">Unassigned</span>
                     )}
                   </SelectValue>
                 </SelectTrigger>
                 <SelectContent className="bg-whatsapp-bg-panel border-whatsapp-divider">
                   <SelectItem 
                     value="unassigned"
                     className="text-whatsapp-text-primary focus:bg-whatsapp-hover focus:text-whatsapp-text-primary"
                   >
                     <span className="text-whatsapp-text-secondary">Unassigned</span>
                   </SelectItem>
                   {designers.map(designer => (
                     <SelectItem 
                       key={designer.id} 
                       value={designer.id}
                       className="text-whatsapp-text-primary focus:bg-whatsapp-hover focus:text-whatsapp-text-primary"
                     >
                       <div className="flex items-center gap-2">
                         <Avatar className="h-6 w-6">
                           <AvatarImage src={designer.avatar} />
                           <AvatarFallback className="bg-whatsapp-green text-white text-xs">
                             {designer.name.charAt(0)}
                           </AvatarFallback>
                         </Avatar>
                         <span>{designer.name}</span>
                       </div>
                     </SelectItem>
                   ))}
                 </SelectContent>
               </Select>
             </div>
           </>
         )}
 
         {/* Divider */}
         <div className="h-2 bg-whatsapp-bg-dark" />
 
         {/* Media & Files */}
         <div className="bg-whatsapp-header">
           <div className="px-6 py-3 flex items-center justify-between">
             <span className="text-whatsapp-text-secondary text-sm">Media, links and docs</span>
             <span className="text-whatsapp-teal text-sm">
               {sharedImages.length + sharedFiles.length}
             </span>
           </div>
           
           {sharedImages.length > 0 && (
             <div className="px-6 pb-4 grid grid-cols-3 gap-1">
               {sharedImages.slice(0, 6).map(img => (
                 <div 
                   key={img.id} 
                   className="aspect-square bg-whatsapp-bg-input rounded overflow-hidden"
                 >
                   <img 
                     src={img.fileUrl} 
                     alt="" 
                     className="w-full h-full object-cover"
                   />
                 </div>
               ))}
             </div>
           )}
         </div>
 
         {/* Divider */}
         <div className="h-2 bg-whatsapp-bg-dark" />
 
         {/* Actions */}
         <div className="bg-whatsapp-header">
           <button className="w-full px-6 py-4 flex items-center gap-6 hover:bg-whatsapp-hover transition-colors">
             <Star className="h-5 w-5 text-whatsapp-icon" />
             <span className="text-whatsapp-text-primary">Starred messages</span>
           </button>
           <button className="w-full px-6 py-4 flex items-center gap-6 hover:bg-whatsapp-hover transition-colors">
             <Bell className="h-5 w-5 text-whatsapp-icon" />
             <span className="text-whatsapp-text-primary">Mute notifications</span>
           </button>
           <button className="w-full px-6 py-4 flex items-center gap-6 hover:bg-whatsapp-hover transition-colors">
             <Lock className="h-5 w-5 text-whatsapp-icon" />
             <span className="text-whatsapp-text-primary">Encryption</span>
           </button>
         </div>
       </ScrollArea>
     </div>
   );
 }