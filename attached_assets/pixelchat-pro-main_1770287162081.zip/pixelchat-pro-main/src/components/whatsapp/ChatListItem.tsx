 import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
 import { Badge } from '@/components/ui/badge';
 import { Chat, TAG_CONFIG } from '@/types/whatsapp';
 import { cn } from '@/lib/utils';
 import { Check, CheckCheck, FileIcon, Mic, Image as ImageIcon } from 'lucide-react';
 import { formatDistanceToNow, isToday, isYesterday, format } from 'date-fns';
 
 interface ChatListItemProps {
   chat: Chat;
   isActive: boolean;
   onClick: () => void;
   showAssignee?: boolean;
 }
 
 export function ChatListItem({ chat, isActive, onClick, showAssignee = true }: ChatListItemProps) {
   const { contact, lastMessage, tag, unreadCount, assignedTo } = chat;
   const tagConfig = TAG_CONFIG[tag];
 
   const formatTimestamp = (date: Date) => {
     if (isToday(date)) {
       return format(date, 'HH:mm');
     }
     if (isYesterday(date)) {
       return 'Yesterday';
     }
     return format(date, 'dd/MM/yyyy');
   };
 
   const getMessagePreview = () => {
     if (!lastMessage) return 'No messages yet';
     
     switch (lastMessage.type) {
       case 'image':
         return (
           <span className="flex items-center gap-1">
             <ImageIcon className="h-3 w-3" />
             Photo
           </span>
         );
       case 'file':
         return (
           <span className="flex items-center gap-1">
             <FileIcon className="h-3 w-3" />
             {lastMessage.fileName || 'Document'}
           </span>
         );
       case 'voice':
         return (
           <span className="flex items-center gap-1">
             <Mic className="h-3 w-3" />
             Voice message
           </span>
         );
       default:
         return lastMessage.content.length > 40 
           ? `${lastMessage.content.substring(0, 40)}...` 
           : lastMessage.content;
     }
   };
 
   const getStatusIcon = () => {
     if (!lastMessage || lastMessage.sender === 'contact') return null;
     
     if (lastMessage.status === 'read') {
       return <CheckCheck className="h-4 w-4 text-whatsapp-teal" />;
     }
     if (lastMessage.status === 'delivered') {
       return <CheckCheck className="h-4 w-4 text-whatsapp-icon" />;
     }
     return <Check className="h-4 w-4 text-whatsapp-icon" />;
   };
 
   return (
     <div
       onClick={onClick}
       className={cn(
         'flex items-center gap-3 px-3 py-3 cursor-pointer transition-colors border-b border-whatsapp-divider',
         isActive ? 'bg-whatsapp-active' : 'hover:bg-whatsapp-hover'
       )}
     >
       {/* Avatar */}
       <div className="relative flex-shrink-0">
         <Avatar className="h-12 w-12">
           <AvatarImage src={contact.avatar} alt={contact.name || contact.phone} />
           <AvatarFallback className="bg-whatsapp-bg-input text-whatsapp-text-primary">
             {(contact.name || contact.phone).charAt(0).toUpperCase()}
           </AvatarFallback>
         </Avatar>
         {/* Tag indicator dot */}
         <div
           className={cn(
             'absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-whatsapp-bg-panel',
             tagConfig.bgClass
           )}
         />
       </div>
 
       {/* Chat info */}
       <div className="flex-1 min-w-0">
         <div className="flex justify-between items-start mb-1">
           <span className="font-medium text-whatsapp-text-primary truncate">
             {contact.name || contact.phone}
           </span>
           <span className={cn(
             'text-xs flex-shrink-0 ml-2',
             unreadCount > 0 ? 'text-whatsapp-unread' : 'text-whatsapp-text-secondary'
           )}>
             {lastMessage && formatTimestamp(lastMessage.timestamp)}
           </span>
         </div>
         
         <div className="flex items-center justify-between gap-2">
           <div className="flex items-center gap-1 text-sm text-whatsapp-text-secondary truncate flex-1 min-w-0">
             {getStatusIcon()}
             <span className="truncate">{getMessagePreview()}</span>
           </div>
           
           <div className="flex items-center gap-2 flex-shrink-0">
             {showAssignee && assignedTo && (
               <span className="text-xs text-whatsapp-teal truncate max-w-[60px]">
                 {assignedTo.name.split(' ')[0]}
               </span>
             )}
             {unreadCount > 0 && (
               <Badge 
                 className="h-5 min-w-[20px] flex items-center justify-center rounded-full bg-whatsapp-unread text-white text-xs font-medium px-1.5"
               >
                 {unreadCount}
               </Badge>
             )}
           </div>
         </div>
       </div>
     </div>
   );
 }