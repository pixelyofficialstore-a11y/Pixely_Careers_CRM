 import { useState, useRef, KeyboardEvent } from 'react';
 import { Smile, Paperclip, Send } from 'lucide-react';
 import { QuickReplyDropdown } from './QuickReplyDropdown';
 import { QuickReply } from '@/types/whatsapp';
 import { mockQuickReplies } from '@/data/mockData';
 
 interface MessageInputProps {
   onSendMessage: (content: string) => void;
   onAttachFile: () => void;
 }
 
 export function MessageInput({ onSendMessage, onAttachFile }: MessageInputProps) {
   const [message, setMessage] = useState('');
   const [showQuickReplies, setShowQuickReplies] = useState(false);
   const [quickReplySearch, setQuickReplySearch] = useState('');
   const [selectedReplyIndex, setSelectedReplyIndex] = useState(0);
   const inputRef = useRef<HTMLInputElement>(null);
 
   const handleChange = (value: string) => {
     setMessage(value);
     
     // Check for "/" trigger
     if (value.startsWith('/')) {
       setShowQuickReplies(true);
       setQuickReplySearch(value.slice(1));
       setSelectedReplyIndex(0);
     } else {
       setShowQuickReplies(false);
       setQuickReplySearch('');
     }
   };
 
   const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
     if (showQuickReplies) {
       const filteredReplies = mockQuickReplies.filter(reply =>
         reply.shortcut.toLowerCase().includes(quickReplySearch.toLowerCase()) ||
         reply.title.toLowerCase().includes(quickReplySearch.toLowerCase())
       );
 
       if (e.key === 'ArrowDown') {
         e.preventDefault();
         setSelectedReplyIndex(prev => 
           prev < filteredReplies.length - 1 ? prev + 1 : 0
         );
       } else if (e.key === 'ArrowUp') {
         e.preventDefault();
         setSelectedReplyIndex(prev => 
           prev > 0 ? prev - 1 : filteredReplies.length - 1
         );
       } else if (e.key === 'Enter' && filteredReplies.length > 0) {
         e.preventDefault();
         handleSelectQuickReply(filteredReplies[selectedReplyIndex]);
       } else if (e.key === 'Escape') {
         setShowQuickReplies(false);
       }
     } else if (e.key === 'Enter' && !e.shiftKey && message.trim()) {
       e.preventDefault();
       handleSend();
     }
   };
 
   const handleSelectQuickReply = (reply: QuickReply) => {
     setMessage(reply.message);
     setShowQuickReplies(false);
     setQuickReplySearch('');
     inputRef.current?.focus();
   };
 
   const handleSend = () => {
     if (message.trim()) {
       onSendMessage(message.trim());
       setMessage('');
       setShowQuickReplies(false);
     }
   };
 
   return (
     <div className="relative px-4 py-3 bg-whatsapp-header">
       <QuickReplyDropdown
         isOpen={showQuickReplies}
         searchQuery={quickReplySearch}
         onSelect={handleSelectQuickReply}
         selectedIndex={selectedReplyIndex}
       />
       
       <div className="flex items-center gap-2">
         <button className="p-2 text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors">
           <Smile className="h-6 w-6" />
         </button>
         
         <button 
           onClick={onAttachFile}
           className="p-2 text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors"
         >
           <Paperclip className="h-6 w-6" />
         </button>
 
         <div className="flex-1">
           <input
             ref={inputRef}
             type="text"
             value={message}
             onChange={(e) => handleChange(e.target.value)}
             onKeyDown={handleKeyDown}
             placeholder="Type a message"
             className="w-full px-4 py-2.5 bg-whatsapp-bg-input text-whatsapp-text-primary placeholder:text-whatsapp-text-secondary rounded-lg border-0 outline-none"
           />
         </div>
 
         <button 
           onClick={handleSend}
           disabled={!message.trim()}
           className="p-2 text-whatsapp-icon hover:text-whatsapp-text-primary transition-colors disabled:opacity-50"
         >
           <Send className="h-6 w-6" />
         </button>
       </div>
     </div>
   );
 }