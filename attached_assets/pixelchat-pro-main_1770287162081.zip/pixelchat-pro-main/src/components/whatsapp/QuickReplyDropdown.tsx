 import { QuickReply } from '@/types/whatsapp';
 import { mockQuickReplies } from '@/data/mockData';
 import { cn } from '@/lib/utils';
 
 interface QuickReplyDropdownProps {
   isOpen: boolean;
   searchQuery: string;
   onSelect: (reply: QuickReply) => void;
   selectedIndex: number;
 }
 
 export function QuickReplyDropdown({ 
   isOpen, 
   searchQuery, 
   onSelect,
   selectedIndex 
 }: QuickReplyDropdownProps) {
   if (!isOpen) return null;
 
   const filteredReplies = mockQuickReplies.filter(reply =>
     reply.shortcut.toLowerCase().includes(searchQuery.toLowerCase()) ||
     reply.title.toLowerCase().includes(searchQuery.toLowerCase())
   );
 
   if (filteredReplies.length === 0) return null;
 
   return (
     <div className="absolute bottom-full left-0 right-0 mb-2 bg-whatsapp-bg-panel border border-whatsapp-divider rounded-lg shadow-xl overflow-hidden z-50">
       <div className="px-3 py-2 border-b border-whatsapp-divider">
         <span className="text-xs text-whatsapp-text-secondary">Quick Replies</span>
       </div>
       <div className="max-h-[240px] overflow-y-auto">
         {filteredReplies.map((reply, index) => (
           <div
             key={reply.id}
             onClick={() => onSelect(reply)}
             className={cn(
               'px-4 py-3 cursor-pointer transition-colors border-b border-whatsapp-divider last:border-0',
               index === selectedIndex ? 'bg-whatsapp-active' : 'hover:bg-whatsapp-hover'
             )}
           >
             <div className="flex items-center gap-2 mb-1">
               <span className="text-whatsapp-green font-mono text-sm">/{reply.shortcut}</span>
               <span className="text-whatsapp-text-primary text-sm">{reply.title}</span>
             </div>
             <p className="text-xs text-whatsapp-text-secondary line-clamp-2">
               {reply.message}
             </p>
           </div>
         ))}
       </div>
     </div>
   );
 }