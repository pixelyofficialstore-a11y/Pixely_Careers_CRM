 import { useState } from 'react';
 import { ChatList } from './ChatList';
 import { ConversationView } from './ConversationView';
 import { ContactInfoPanel } from './ContactInfoPanel';
 import { Chat, ChatTag, UserRole, Message } from '@/types/whatsapp';
 import { mockChats, mockUsers, currentUser } from '@/data/mockData';
 
 interface WhatsAppLayoutProps {
   userRole?: UserRole;
 }
 
 export function WhatsAppLayout({ userRole = currentUser.role }: WhatsAppLayoutProps) {
   const [chats, setChats] = useState<Chat[]>(mockChats);
   const [activeChat, setActiveChat] = useState<Chat | null>(null);
   const [showContactInfo, setShowContactInfo] = useState(false);
 
   const handleSelectChat = (chat: Chat) => {
     setActiveChat(chat);
     // Mark messages as read
     setChats(prev => prev.map(c => 
       c.id === chat.id ? { ...c, unreadCount: 0 } : c
     ));
   };
 
   const handleSendMessage = (chatId: string, content: string) => {
     const newMessage: Message = {
       id: `msg-${Date.now()}`,
       chatId,
       content,
       type: 'text',
       sender: 'user',
       timestamp: new Date(),
       status: 'sent',
     };
 
     setChats(prev => prev.map(chat => {
       if (chat.id === chatId) {
         const updatedMessages = [...chat.messages, newMessage];
         return {
           ...chat,
           messages: updatedMessages,
           updatedAt: new Date(),
         };
       }
       return chat;
     }));
 
     // Update active chat
     if (activeChat?.id === chatId) {
       setActiveChat(prev => prev ? {
         ...prev,
         messages: [...prev.messages, newMessage],
       } : null);
     }
 
     // Simulate delivery after 1 second
     setTimeout(() => {
       setChats(prev => prev.map(chat => {
         if (chat.id === chatId) {
           return {
             ...chat,
             messages: chat.messages.map(m => 
               m.id === newMessage.id ? { ...m, status: 'delivered' as const } : m
             ),
           };
         }
         return chat;
       }));
 
       if (activeChat?.id === chatId) {
         setActiveChat(prev => prev ? {
           ...prev,
           messages: prev.messages.map(m => 
             m.id === newMessage.id ? { ...m, status: 'delivered' as const } : m
           ),
         } : null);
       }
     }, 1000);
   };
 
   const handleUpdateTag = (chatId: string, tag: ChatTag) => {
     setChats(prev => prev.map(chat => {
       if (chat.id === chatId) {
         // If "satisfied" tag, auto-unassign
         const updates: Partial<Chat> = { tag };
         if (tag === 'satisfied') {
           updates.assignedTo = undefined;
         }
         return { ...chat, ...updates };
       }
       return chat;
     }));
 
     if (activeChat?.id === chatId) {
       setActiveChat(prev => {
         if (!prev) return null;
         const updates: Partial<Chat> = { tag };
         if (tag === 'satisfied') {
           updates.assignedTo = undefined;
         }
         return { ...prev, ...updates };
       });
     }
   };
 
   const handleAssignDesigner = (chatId: string, designerId: string | null) => {
     const designer = designerId ? mockUsers.find(u => u.id === designerId) : undefined;
     
     setChats(prev => prev.map(chat => {
       if (chat.id === chatId) {
         return { ...chat, assignedTo: designer };
       }
       return chat;
     }));
 
     if (activeChat?.id === chatId) {
       setActiveChat(prev => prev ? { ...prev, assignedTo: designer } : null);
     }
   };
 
   // Get the active chat from current state
   const currentActiveChat = activeChat ? chats.find(c => c.id === activeChat.id) || activeChat : null;
 
   return (
     <div className="flex h-screen w-full bg-whatsapp-bg-dark">
       {/* Left Sidebar - Chat List */}
       <div className="w-[400px] flex-shrink-0">
         <ChatList
           activeChat={currentActiveChat}
           onSelectChat={handleSelectChat}
           userRole={userRole}
         />
       </div>
 
       {/* Center - Conversation View */}
       <ConversationView
         chat={currentActiveChat}
         onSendMessage={handleSendMessage}
         onToggleContactInfo={() => setShowContactInfo(!showContactInfo)}
       />
 
       {/* Right Panel - Contact Info (conditional) */}
       {showContactInfo && currentActiveChat && (
         <ContactInfoPanel
           chat={currentActiveChat}
           userRole={userRole}
           onClose={() => setShowContactInfo(false)}
           onUpdateTag={handleUpdateTag}
           onAssignDesigner={handleAssignDesigner}
         />
       )}
     </div>
   );
 }