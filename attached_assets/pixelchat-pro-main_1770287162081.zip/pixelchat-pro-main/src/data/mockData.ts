 import { Chat, User, QuickReply, Message, Contact } from '@/types/whatsapp';
 
 // Mock Users (team members)
 export const mockUsers: User[] = [
   {
     id: 'user-1',
     name: 'Ahmed Hassan',
     email: 'ahmed@pixelcrm.com',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmed',
     role: 'admin',
     isOnline: true,
   },
   {
     id: 'user-2',
     name: 'Sara Mohamed',
     email: 'sara@pixelcrm.com',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sara',
     role: 'support',
     isOnline: true,
   },
   {
     id: 'user-3',
     name: 'Omar Youssef',
     email: 'omar@pixelcrm.com',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Omar',
     role: 'designer',
     isOnline: true,
   },
   {
     id: 'user-4',
     name: 'Layla Ibrahim',
     email: 'layla@pixelcrm.com',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Layla',
     role: 'designer',
     isOnline: false,
   },
 ];
 
 // Mock Contacts (WhatsApp clients)
 const mockContacts: Contact[] = [
   {
     id: 'contact-1',
     name: 'Mohammad Ali',
     phone: '+971 50 123 4567',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mohammad',
     isOnline: true,
   },
   {
     id: 'contact-2',
     name: 'Fatima Al-Rashid',
     phone: '+971 55 234 5678',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Fatima',
     isOnline: false,
     lastSeen: new Date(Date.now() - 1000 * 60 * 15),
   },
   {
     id: 'contact-3',
     phone: '+971 52 345 6789',
     isOnline: false,
     lastSeen: new Date(Date.now() - 1000 * 60 * 60 * 2),
   },
   {
     id: 'contact-4',
     name: 'Abdullah Khaled',
     phone: '+971 56 456 7890',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Abdullah',
     isOnline: true,
   },
   {
     id: 'contact-5',
     name: 'Mariam Hossam',
     phone: '+971 54 567 8901',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mariam',
     isOnline: false,
     lastSeen: new Date(Date.now() - 1000 * 60 * 60 * 24),
   },
   {
     id: 'contact-6',
     name: 'Youssef Nasser',
     phone: '+971 58 678 9012',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Youssef',
     isOnline: true,
   },
   {
     id: 'contact-7',
     phone: '+971 50 789 0123',
     isOnline: false,
     lastSeen: new Date(Date.now() - 1000 * 60 * 30),
   },
   {
     id: 'contact-8',
     name: 'Noura Salem',
     phone: '+971 55 890 1234',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Noura',
     isOnline: false,
     lastSeen: new Date(Date.now() - 1000 * 60 * 60 * 5),
   },
   {
     id: 'contact-9',
     name: 'Khalid Mansour',
     phone: '+971 52 901 2345',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Khalid',
     isOnline: true,
   },
   {
     id: 'contact-10',
     name: 'Rania Gamal',
     phone: '+971 56 012 3456',
     avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rania',
     isOnline: false,
     lastSeen: new Date(Date.now() - 1000 * 60 * 60 * 48),
   },
 ];
 
 // Helper to create messages
 const createMessage = (
   id: string,
   chatId: string,
   content: string,
   sender: 'user' | 'contact',
   minutesAgo: number,
   type: Message['type'] = 'text',
   status: Message['status'] = 'read',
   extras?: Partial<Message>
 ): Message => ({
   id,
   chatId,
   content,
   type,
   sender,
   timestamp: new Date(Date.now() - minutesAgo * 60 * 1000),
   status,
   ...extras,
 });
 
 // Mock Chats with messages
 export const mockChats: Chat[] = [
   {
     id: 'chat-1',
     contact: mockContacts[0],
     tag: 'working',
     assignedTo: mockUsers[2], // Omar (designer)
     unreadCount: 2,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
     updatedAt: new Date(Date.now() - 1000 * 60 * 5),
     messages: [
       createMessage('msg-1-1', 'chat-1', 'Hello! I need a new logo for my restaurant', 'contact', 1440),
       createMessage('msg-1-2', 'chat-1', 'Of course! Can you share more details about your brand?', 'user', 1420),
       createMessage('msg-1-3', 'chat-1', 'It\'s an Italian restaurant called "Bella Vista"', 'contact', 1400),
       createMessage('msg-1-4', 'chat-1', 'Great! I\'ll start working on some concepts', 'user', 1380),
       createMessage('msg-1-5', 'chat-1', 'Here\'s the first draft', 'user', 60, 'file', 'read', {
         fileName: 'bella-vista-logo-v1.pdf',
         fileSize: 2400000,
       }),
       createMessage('msg-1-6', 'chat-1', 'I love the design! Can we try different colors?', 'contact', 30),
       createMessage('msg-1-7', 'chat-1', 'Sure, what colors do you prefer?', 'user', 15, 'text', 'delivered'),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-2',
     contact: mockContacts[1],
     tag: 'new',
     unreadCount: 3,
     createdAt: new Date(Date.now() - 1000 * 60 * 30),
     updatedAt: new Date(Date.now() - 1000 * 60 * 10),
     messages: [
       createMessage('msg-2-1', 'chat-2', 'Hi, I saw your work on Instagram', 'contact', 30),
       createMessage('msg-2-2', 'chat-2', 'I need business cards and letterhead', 'contact', 28),
       createMessage('msg-2-3', 'chat-2', 'Can you send me your price list?', 'contact', 25),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-3',
     contact: mockContacts[2],
     tag: 'pending',
     assignedTo: mockUsers[3], // Layla (designer)
     unreadCount: 0,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
     updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 4),
     messages: [
       createMessage('msg-3-1', 'chat-3', 'I need a flyer for my event', 'contact', 4320),
       createMessage('msg-3-2', 'chat-3', 'What are the event details?', 'user', 4300),
       createMessage('msg-3-3', 'chat-3', 'It\'s a tech conference next month', 'contact', 4280),
       createMessage('msg-3-4', 'chat-3', 'Here\'s the draft design', 'user', 1440, 'image', 'read', {
         fileUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400',
       }),
       createMessage('msg-3-5', 'chat-3', 'I need to check with my team and get back to you', 'contact', 240),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-4',
     contact: mockContacts[3],
     tag: 'issues',
     assignedTo: mockUsers[2], // Omar (designer)
     unreadCount: 5,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7),
     updatedAt: new Date(Date.now() - 1000 * 60 * 2),
     messages: [
       createMessage('msg-4-1', 'chat-4', 'The website isn\'t loading correctly', 'contact', 120),
       createMessage('msg-4-2', 'chat-4', 'Can you send me a screenshot?', 'user', 110),
       createMessage('msg-4-3', 'chat-4', 'Here it is', 'contact', 100, 'image', 'read', {
         fileUrl: 'https://images.unsplash.com/photo-1555861496-0666c8981751?w=400',
       }),
       createMessage('msg-4-4', 'chat-4', 'I see the issue, working on it now', 'user', 90),
       createMessage('msg-4-5', 'chat-4', 'It\'s still not working', 'contact', 30),
       createMessage('msg-4-6', 'chat-4', 'I tried clearing my cache but same problem', 'contact', 20),
       createMessage('msg-4-7', 'chat-4', 'Please help, this is urgent!', 'contact', 10),
       createMessage('msg-4-8', 'chat-4', 'I need this fixed today', 'contact', 5),
       createMessage('msg-4-9', 'chat-4', 'HELLO?', 'contact', 2),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-5',
     contact: mockContacts[4],
     tag: 'satisfied',
     unreadCount: 0,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14),
     updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
     messages: [
       createMessage('msg-5-1', 'chat-5', 'Thank you so much for the amazing work!', 'contact', 2880),
       createMessage('msg-5-2', 'chat-5', 'You\'re welcome! Glad you loved it 😊', 'user', 2860),
       createMessage('msg-5-3', 'chat-5', 'I\'ll definitely recommend you to my friends', 'contact', 2840),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-6',
     contact: mockContacts[5],
     tag: 'working',
     assignedTo: mockUsers[3], // Layla (designer)
     unreadCount: 1,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48),
     updatedAt: new Date(Date.now() - 1000 * 60 * 45),
     messages: [
       createMessage('msg-6-1', 'chat-6', 'I need a complete brand identity', 'contact', 2880),
       createMessage('msg-6-2', 'chat-6', 'That includes logo, colors, and brand guidelines', 'user', 2850),
       createMessage('msg-6-3', 'chat-6', 'Yes exactly! Here\'s my brief', 'contact', 2800, 'file', 'read', {
         fileName: 'brand-brief.docx',
         fileSize: 45000,
       }),
       createMessage('msg-6-4', 'chat-6', '', 'contact', 60, 'voice', 'read', {
         duration: 45,
       }),
       createMessage('msg-6-5', 'chat-6', 'Got it! Will review and get back to you', 'user', 50),
       createMessage('msg-6-6', 'chat-6', 'When can I expect the first draft?', 'contact', 45),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-7',
     contact: mockContacts[6],
     tag: 'new',
     unreadCount: 1,
     createdAt: new Date(Date.now() - 1000 * 60 * 15),
     updatedAt: new Date(Date.now() - 1000 * 60 * 15),
     messages: [
       createMessage('msg-7-1', 'chat-7', 'Hi, do you do menu designs?', 'contact', 15),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-8',
     contact: mockContacts[7],
     tag: 'working',
     assignedTo: mockUsers[2], // Omar (designer)
     unreadCount: 0,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72),
     updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 8),
     messages: [
       createMessage('msg-8-1', 'chat-8', 'Need packaging design for my coffee brand', 'contact', 4320),
       createMessage('msg-8-2', 'chat-8', 'Exciting! What\'s your vision?', 'user', 4300),
       createMessage('msg-8-3', 'chat-8', 'Something modern and minimal', 'contact', 4280),
       createMessage('msg-8-4', 'chat-8', 'Here are some initial mockups', 'user', 480, 'file', 'read', {
         fileName: 'coffee-packaging-concepts.pdf',
         fileSize: 5600000,
       }),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-9',
     contact: mockContacts[8],
     tag: 'pending',
     assignedTo: mockUsers[2], // Omar (designer)
     unreadCount: 0,
     createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10),
     updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24),
     messages: [
       createMessage('msg-9-1', 'chat-9', 'Your design is ready!', 'user', 1440),
       createMessage('msg-9-2', 'chat-9', 'Awaiting your payment to proceed', 'user', 1440),
       createMessage('msg-9-3', 'chat-9', 'I\'ll pay tomorrow, thanks!', 'contact', 1420),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
   {
     id: 'chat-10',
     contact: mockContacts[9],
     tag: 'new',
     unreadCount: 2,
     createdAt: new Date(Date.now() - 1000 * 60 * 60),
     updatedAt: new Date(Date.now() - 1000 * 60 * 55),
     messages: [
       createMessage('msg-10-1', 'chat-10', 'Hello! I need help with social media posts', 'contact', 60),
       createMessage('msg-10-2', 'chat-10', 'For my new makeup brand', 'contact', 55),
     ],
     get lastMessage() {
       return this.messages[this.messages.length - 1];
     },
   },
 ];
 
 // Mock Quick Replies
 export const mockQuickReplies: QuickReply[] = [
   {
     id: 'qr-1',
     shortcut: 'payment',
     title: 'Payment Instructions',
     message: 'Thank you for choosing our services! 💳\n\nPlease send your payment to:\nBank: Emirates NBD\nAccount: 1234567890\nIBAN: AE12345678901234567890\n\nOnce payment is received, we\'ll proceed with your order.',
   },
   {
     id: 'qr-2',
     shortcut: 'ready',
     title: 'Design Ready',
     message: 'Great news! 🎉 Your design is ready!\n\nPlease review the attached files and let me know if you need any changes. I\'ll be happy to make revisions.',
   },
   {
     id: 'qr-3',
     shortcut: 'thanks',
     title: 'Thank You',
     message: 'Thank you so much for your business! 🙏\n\nIt was a pleasure working with you. Please don\'t hesitate to reach out if you need anything else in the future.',
   },
   {
     id: 'qr-4',
     shortcut: 'delay',
     title: 'Delay Notice',
     message: 'I apologize for the delay. ⏰\n\nI\'m working on your project and will have it ready within the next 24 hours. Thank you for your patience!',
   },
   {
     id: 'qr-5',
     shortcut: 'revision',
     title: 'Revision Request',
     message: 'I\'d be happy to make revisions! ✏️\n\nPlease list all the changes you\'d like, and I\'ll update the design accordingly.',
   },
   {
     id: 'qr-6',
     shortcut: 'pricing',
     title: 'Pricing Info',
     message: 'Here\'s our pricing:\n\n📋 Logo Design: 500 AED\n📋 Business Card: 200 AED\n📋 Social Media Pack: 800 AED\n📋 Full Branding: 2000 AED\n\nAll prices include 2 revision rounds.',
   },
 ];
 
 // Current logged in user (for demo purposes)
 export const currentUser = mockUsers[0]; // Admin by default