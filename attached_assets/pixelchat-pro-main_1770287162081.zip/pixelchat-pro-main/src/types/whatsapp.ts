 export type UserRole = 'admin' | 'support' | 'designer';
 
 export type ChatTag = 'new' | 'working' | 'pending' | 'issues' | 'satisfied';
 
 export interface User {
   id: string;
   name: string;
   email: string;
   avatar?: string;
   role: UserRole;
   isOnline?: boolean;
 }
 
 export interface Contact {
   id: string;
   name?: string;
   phone: string;
   avatar?: string;
   isOnline?: boolean;
   lastSeen?: Date;
 }
 
 export interface Message {
   id: string;
   chatId: string;
   content: string;
   type: 'text' | 'image' | 'file' | 'voice' | 'video';
   sender: 'user' | 'contact';
   timestamp: Date;
   status: 'sent' | 'delivered' | 'read';
   fileName?: string;
   fileSize?: number;
   fileUrl?: string;
   duration?: number; // for voice/video
   mimeType?: string;
 }
 
 export interface Chat {
   id: string;
   contact: Contact;
   messages: Message[];
   tag: ChatTag;
   assignedTo?: User;
   unreadCount: number;
   lastMessage?: Message;
   createdAt: Date;
   updatedAt: Date;
 }
 
 export interface QuickReply {
   id: string;
   shortcut: string;
   title: string;
   message: string;
 }
 
 export const TAG_CONFIG: Record<ChatTag, { label: string; color: string; bgClass: string }> = {
   new: { label: 'New', color: 'tag-new', bgClass: 'bg-tag-new' },
   working: { label: 'Working', color: 'tag-working', bgClass: 'bg-tag-working' },
   pending: { label: 'Pending', color: 'tag-pending', bgClass: 'bg-tag-pending' },
   issues: { label: 'Issues', color: 'tag-issues', bgClass: 'bg-tag-issues' },
   satisfied: { label: 'Satisfied', color: 'tag-satisfied', bgClass: 'bg-tag-satisfied' },
 };